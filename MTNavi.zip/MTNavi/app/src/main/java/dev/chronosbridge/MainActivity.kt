package dev.chronosbridge

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import dev.chronosbridge.ble.ChronosBle
import dev.chronosbridge.protocol.ChronosPackets
import dev.chronosbridge.protocol.NavInfo

/** Минимальный экран: доступ к уведомлениям, подключение по BLE, тестовые пакеты. UI собран кодом, без XML. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var namePrefix: EditText
    private var ble: ChronosBle? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun button(title: String, action: () -> Unit) = Button(this).apply {
            text = title
            setOnClickListener { action() }
        }

        status = TextView(this).apply { text = "Не подключено"; textSize = 18f }
        namePrefix = EditText(this).apply {
            setText("Chronos")
            hint = "Начало имени BLE-устройства"
            setSingleLine()
        }
        val mirror = CheckBox(this).apply {
            text = "Дублировать уведомления приложений"
            isChecked = BridgeListenerService.mirrorEnabled
            setOnCheckedChangeListener { _, v -> BridgeListenerService.mirrorEnabled = v }
        }

        root.addView(status)
        root.addView(button("1. Доступ к уведомлениям") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(namePrefix, LinearLayout.LayoutParams(MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(button("2. Найти и подключиться") { connect() })
        root.addView(button("Тест: показать навигацию") {
            send(
                ChronosPackets.navigationText(
                    NavInfo(
                        title = "300 м",
                        duration = "1 ч 25 мин",
                        distance = "84 км",
                        eta = "23:56",
                        directions = "Поверните направо"
                    )
                )
            )
        })
        root.addView(button("Тест: остановить навигацию") { send(ChronosPackets.navigationStop()) })
        root.addView(mirror)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun send(packet: ByteArray) {
        val c = ble
        if (c == null || !c.isReady) {
            toast("Сначала подключитесь к устройству")
            return
        }
        c.send(packet)
    }

    private fun connect() {
        if (!hasBlePermissions()) {
            requestBlePermissions()
            return
        }
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter
        if (adapter == null || !adapter.isEnabled) {
            status.text = "Включите Bluetooth"
            return
        }
        val client = ble ?: ChronosBle(applicationContext) { ok ->
            runOnUiThread { status.text = if (ok) "Подключено" else "Отключено" }
        }.also {
            ble = it
            BridgeListenerService.ble = it
        }
        status.text = "Поиск устройства…"
        client.scanAndConnect(adapter, namePrefix.text.toString().trim())
    }

    private fun neededPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun hasBlePermissions() = neededPermissions().all {
        checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestBlePermissions() = requestPermissions(neededPermissions(), 1)

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasBlePermissions()) toast("Разрешения выданы, нажмите «Найти и подключиться» ещё раз")
        else toast("Без разрешений Bluetooth подключение невозможно")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
