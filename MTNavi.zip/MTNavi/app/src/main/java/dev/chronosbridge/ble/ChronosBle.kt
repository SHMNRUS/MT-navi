package dev.chronosbridge.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.UUID

private const val TAG = "ChronosBle"

val NUS_SERVICE: UUID = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
val NUS_RX: UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e") // телефон -> устройство (WRITE)
val NUS_TX: UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e") // устройство -> телефон (NOTIFY)
private val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

/**
 * Прямое GATT-подключение (БЕЗ системного спаривания — библиотека ChronosESP32 этого не хочет).
 * Нужны разрешения BLUETOOTH_CONNECT / BLUETOOTH_SCAN (Android 12+), их запрашивает Activity.
 * Важно: пока подключено официальное приложение Chronos, ваше приложение подключиться не сможет.
 */
@Suppress("DEPRECATION")
@SuppressLint("MissingPermission")
class ChronosBle(
    private val ctx: Context,
    private val onState: (connected: Boolean) -> Unit = {}
) {
    private val main = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private var rx: BluetoothGattCharacteristic? = null
    private var mtu = 23
    private val queue = ArrayDeque<ByteArray>()
    private var writing = false
    private var scanCb: ScanCallback? = null

    @Volatile
    var isReady = false
        private set

    // ---------- подключение ----------

    fun connectByAddress(adapter: BluetoothAdapter, mac: String) =
        connect(adapter.getRemoteDevice(mac))

    /** Ищет устройство по префиксу имени (имя BLE-рекламы задаётся в прошивке) и подключается. */
    fun scanAndConnect(adapter: BluetoothAdapter, namePrefix: String, timeoutMs: Long = 15_000) {
        val scanner = adapter.bluetoothLeScanner ?: return
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, r: ScanResult) {
                val name = r.scanRecord?.deviceName ?: r.device.name ?: return
                if (name.startsWith(namePrefix, ignoreCase = true)) {
                    scanner.stopScan(this)
                    scanCb = null
                    connect(r.device)
                }
            }
        }
        scanCb = cb
        scanner.startScan(cb)
        main.postDelayed({
            scanCb?.let { scanner.stopScan(it); scanCb = null }
        }, timeoutMs)
    }

    fun connect(device: BluetoothDevice) {
        close()
        gatt = device.connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    fun close() {
        isReady = false
        synchronized(queue) { queue.clear(); writing = false }
        gatt?.close()
        gatt = null
        rx = null
    }

    // ---------- отправка ----------

    /** Кладёт пакет в очередь (с фрагментацией Chronos при необходимости). */
    fun send(packet: ByteArray) {
        if (!isReady) return
        synchronized(queue) { fragment(packet, mtu).forEach { queue.addLast(it) } }
        pump()
    }

    /**
     * Если пакет влезает в одну запись (MTU-3) — отправляем целиком.
     * Иначе схема ChronosESP32: первый сегмент ровно 20 байт, дальше сегменты
     * [индекс 0,1,2..] + до 19 байт данных (библиотека кладёт их со смещения 20 + индекс*19).
     */
    private fun fragment(p: ByteArray, mtu: Int): List<ByteArray> {
        if (p.size <= mtu - 3 || p.size <= 20) return listOf(p)
        val out = mutableListOf(p.copyOfRange(0, 20))
        var off = 20
        var idx = 0
        while (off < p.size) {
            val n = minOf(19, p.size - off)
            val seg = ByteArray(n + 1)
            seg[0] = idx.toByte()
            System.arraycopy(p, off, seg, 1, n)
            out += seg
            off += n
            idx++
        }
        return out
    }

    private fun pump() {
        val g = gatt ?: return
        val c = rx ?: return
        val chunk = synchronized(queue) {
            if (writing || queue.isEmpty()) null else queue.removeFirst().also { writing = true }
        } ?: return

        val ok = if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(c, chunk, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) ==
                BluetoothStatusCodes.SUCCESS
        } else {
            run {
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                c.value = chunk
                g.writeCharacteristic(c)
            }
        }
        if (!ok) {
            Log.w(TAG, "write failed, dropping queue")
            synchronized(queue) { writing = false; queue.clear() }
        }
    }

    // ---------- GATT ----------

    private val callback = object : BluetoothGattCallback() {

        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                if (!g.requestMtu(247)) g.discoverServices()
            } else {
                isReady = false
                main.post { onState(false) }
                g.close()
                if (gatt === g) gatt = null
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, m: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) mtu = m
            g.discoverServices()
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val svc = g.getService(NUS_SERVICE)
            rx = svc?.getCharacteristic(NUS_RX)
            val tx = svc?.getCharacteristic(NUS_TX)
            val cccd = tx?.getDescriptor(CCCD)
            if (tx != null && cccd != null) {
                g.setCharacteristicNotification(tx, true)
                if (Build.VERSION.SDK_INT >= 33) {
                    g.writeDescriptor(cccd, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                } else {
                    run {
                        cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        g.writeDescriptor(cccd)
                    }
                }
            } else {
                markReady()
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            markReady()
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            synchronized(queue) { writing = false }
            pump()
        }
    }

    private fun markReady() {
        isReady = rx != null
        main.post { onState(isReady) }
        pump()
    }
}
