package dev.chronosbridge.protocol

import java.io.ByteArrayOutputStream

/** Поля навигации, которые понимает ChronosESP32 (все — просто строки). */
data class NavInfo(
    val title: String = "",       // расстояние до ближайшего манёвра ("300 м")
    val duration: String = "",    // ПОЛНОЕ оставшееся время ("1 ч 25 мин"), не только минуты
    val distance: String = "",    // оставшееся расстояние до цели
    val eta: String = "",         // время прибытия ("23:56")
    val directions: String = "",  // текст манёвра / улица
    val speed: String = ""
)

object ChronosPackets {

    private const val MAX_FIELD_BYTES = 80

    /**
     * Навигационный текстовый пакет: 0xAB | len(BE) | 0xFE 0xEF 0x80 | hasIcon | isNav | crc[4] | строки\0
     * Раскладка взята из описания ChronosESP32 (CF_NAV_DATA, status 0x80).
     * Без иконки (hasIcon=0) — MVP; иконка 48x48 1bpp идёт отдельными пакетами 0xEE.
     */
    fun navigationText(nav: NavInfo, hasIcon: Boolean = false, iconCrc: Long = 0L): ByteArray {
        val body = ByteArrayOutputStream()
        body.write(0xFE); body.write(0xEF); body.write(0x80)
        body.write(if (hasIcon) 1 else 0)
        body.write(1) // isNavigation = true
        for (shift in intArrayOf(24, 16, 8, 0)) body.write(((iconCrc shr shift) and 0xFF).toInt())
        // порядок строго такой: title, duration, distance, eta, directions, speed
        for (s in listOf(nav.title, nav.duration, nav.distance, nav.eta, nav.directions, nav.speed)) {
            body.write(cstr(s)); body.write(0)
        }
        return frame(body.toByteArray())
    }

    /** Навигация выключена (status 0x00) — устройство вернёт заглушку. */
    fun navigationStop(): ByteArray = frame(byteArrayOf(0xFE.toByte(), 0xEF.toByte(), 0x00))

    /**
     * ВНИМАНИЕ: раскладка пакета уведомления НЕ проверена.
     * Её нужно взять из ChronosESP32::dataReceived() (ветка, которая заполняет struct Notification:
     * icon, app, time, title, message). Пока возвращаем null — сервис просто ничего не отправит.
     */
    fun notification(app: String, title: String, text: String): ByteArray? = null

    // 0xAB, длина тела (BE, без 3 байт заголовка), тело
    private fun frame(body: ByteArray): ByteArray {
        val out = ByteArray(body.size + 3)
        out[0] = 0xAB.toByte()
        out[1] = (body.size shr 8).toByte()
        out[2] = body.size.toByte()
        System.arraycopy(body, 0, out, 3, body.size)
        return out
    }

    private fun cstr(s: String): ByteArray {
        val bytes = s.replace('\u0000', ' ').trim().toByteArray(Charsets.UTF_8)
        if (bytes.size <= MAX_FIELD_BYTES) return bytes
        var end = MAX_FIELD_BYTES
        while (end > 0 && (bytes[end].toInt() and 0xC0) == 0x80) end-- // не рвём UTF-8 символ
        return bytes.copyOfRange(0, end)
    }
}
