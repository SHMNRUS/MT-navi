package dev.chronosbridge.maps

import android.app.Notification
import android.os.Bundle
import dev.chronosbridge.protocol.NavInfo

object NavSources {
    const val YANDEX_NAVI = "ru.yandex.yandexnavi"
    const val YANDEX_MAPS = "ru.yandex.yandexmaps"
    const val DGIS = "ru.dublgis.dgismobile"
    val all = setOf(YANDEX_NAVI, YANDEX_MAPS, DGIS)
}

private fun Bundle.textOf(key: String): String = getCharSequence(key)?.toString()?.trim().orEmpty()

/** Все текстовые поля уведомления одним списком (без повторов). */
fun Notification.allTexts(): List<String> {
    val e = extras ?: return emptyList()
    val out = mutableListOf<String>()
    for (k in listOf(
        Notification.EXTRA_TITLE,
        Notification.EXTRA_TEXT,
        Notification.EXTRA_SUB_TEXT,
        Notification.EXTRA_BIG_TEXT,
        Notification.EXTRA_SUMMARY_TEXT
    )) {
        val s = e.textOf(k)
        if (s.isNotEmpty()) out += s
    }
    e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.forEach { out += it.toString() }
    return out.distinct()
}

/** Дамп всех extras в лог — нужен, чтобы увидеть, что реально кладут 2ГИС/Яндекс. */
@Suppress("DEPRECATION")
fun Notification.dump(pkg: String): String = buildString {
    append("pkg=$pkg flags=$flags ongoing=${flags and Notification.FLAG_ONGOING_EVENT != 0}\n")
    val e = extras ?: return@buildString
    for (k in e.keySet()) append("  $k = ${e.get(k)}\n")
}

/**
 * ЭВРИСТИКА. Форматы уведомлений 2ГИС и Яндекса я не проверял — разбираем по шаблонам:
 * расстояния ("300 м", "4,5 км"), время ("1 ч 25 мин"), ETA ("23:56").
 * После просмотра дампа (Log tag "NavDump") пишите отдельные парсеры под каждое приложение.
 */
object HeuristicNavParser {
    private val dist = Regex("""(\d+(?:[.,]\d+)?)\s*(км|м|km|m)(?!\p{L})""", RegexOption.IGNORE_CASE)
    private val hours = Regex("""(\d+)\s*(?:ч|час\p{L}*|h|hr)(?!\p{L})""", RegexOption.IGNORE_CASE)
    private val mins = Regex("""(\d+)\s*(?:мин\p{L}*|min\p{L}*)""", RegexOption.IGNORE_CASE)
    private val eta = Regex("""(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?!\d)""")

    fun parse(texts: List<String>): NavInfo? {
        if (texts.isEmpty()) return null
        val joined = texts.joinToString(" | ")

        val ds = dist.findAll(joined).map { it.value.trim() }.toList()
        val h = hours.find(joined)?.groupValues?.get(1)
        val m = mins.find(joined)?.groupValues?.get(1)
        // всегда полное время: часы + минуты, а не только минуты
        val duration = listOfNotNull(h?.let { "$it ч" }, m?.let { "$it мин" }).joinToString(" ")
        val etaStr = eta.find(joined)?.value.orEmpty()

        if (ds.isEmpty() && duration.isEmpty() && etaStr.isEmpty()) return null

        val directions = texts.firstOrNull { line -> line.none { it.isDigit() } } ?: texts.first()
        return NavInfo(
            title = ds.firstOrNull().orEmpty(),               // до ближайшего манёвра
            distance = if (ds.size >= 2) ds.last() else "",   // до цели
            duration = duration,
            eta = etaStr,
            directions = directions
        )
    }
}

/** Точка расширения: под каждое приложение можно подставить свой парсер. */
fun parserFor(pkg: String): (List<String>) -> NavInfo? = when (pkg) {
    NavSources.YANDEX_NAVI, NavSources.YANDEX_MAPS, NavSources.DGIS -> HeuristicNavParser::parse
    else -> { _ -> null }
}
