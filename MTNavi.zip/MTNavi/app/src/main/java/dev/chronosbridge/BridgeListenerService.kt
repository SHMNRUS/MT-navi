package dev.chronosbridge

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import dev.chronosbridge.ble.ChronosBle
import dev.chronosbridge.maps.NavSources
import dev.chronosbridge.maps.allTexts
import dev.chronosbridge.maps.dump
import dev.chronosbridge.maps.parserFor
import dev.chronosbridge.protocol.ChronosPackets
import dev.chronosbridge.protocol.NavInfo

private const val TAG = "Bridge"

class BridgeListenerService : NotificationListenerService() {

    companion object {
        /** Activity создаёт ChronosBle (после выдачи разрешений) и кладёт сюда. */
        @Volatile var ble: ChronosBle? = null
        @Volatile var mirrorEnabled = true
        @Volatile var debugDump = true   // выключить, когда парсеры настроены
    }

    private var lastNav: NavInfo? = null
    private var lastSentAt = 0L

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return
            if (sbn.packageName in NavSources.all) handleNav(sbn) else if (mirrorEnabled) handleMirror(sbn)
        } catch (t: Throwable) {
            Log.e(TAG, "notification error", t) // OEM-прошивки любят кидать неожиданные исключения
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName in NavSources.all) {
            lastNav = null
            ble?.send(ChronosPackets.navigationStop())
        }
    }

    private fun handleNav(sbn: StatusBarNotification) {
        val n = sbn.notification
        if (debugDump) Log.d("NavDump", n.dump(sbn.packageName))

        val info = parserFor(sbn.packageName)(n.allTexts()) ?: return
        val now = System.currentTimeMillis()
        if (info == lastNav || now - lastSentAt < 500) return   // не спамим одинаковым
        lastNav = info
        lastSentAt = now
        ble?.send(ChronosPackets.navigationText(info))
    }

    private fun handleMirror(sbn: StatusBarNotification) {
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return

        val texts = n.allTexts()
        val title = n.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = texts.firstOrNull { it != title }.orEmpty()
        if (title.isEmpty() && text.isEmpty()) return

        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        // пока null: раскладка пакета уведомления не проверена (см. ChronosPackets.notification)
        ChronosPackets.notification(app, title, text)?.let { ble?.send(it) }
    }
}
